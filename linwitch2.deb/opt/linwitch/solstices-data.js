const solstices= {
  "evenements": [
    { nom: "Équinoxe de printemps", date: "2025-03-20" },
    { nom: "Solstice d’été", date: "2025-06-21" },
    { nom: "Équinoxe d’automne", date: "2025-09-22" },
    { nom: "Solstice d’hiver", date: "2025-12-21" },

    { nom: "Équinoxe de printemps", date: "2026-03-20" },
    { nom: "Solstice d’été", date: "2026-06-21" },
    { nom: "Équinoxe d’automne", date: "2026-09-23" },
    { nom: "Solstice d’hiver", date: "2026-12-21" },
  
    { "nom": "Équinoxe de printemps", "date": "2027-03-20" },
    { "nom": "Solstice d’été", "date": "2027-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2027-09-23" },
    { "nom": "Solstice d’hiver", "date": "2027-12-22" },
    
    { "nom": "Équinoxe de printemps", "date": "2028-03-20" },
    { "nom": "Solstice d’été", "date": "2028-06-20" },
    { "nom": "Équinoxe d’automne", "date": "2028-09-22" },
    { "nom": "Solstice d’hiver", "date": "2028-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2029-03-20" },
    { "nom": "Solstice d’été", "date": "2029-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2029-09-22" },
    { "nom": "Solstice d’hiver", "date": "2029-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2030-03-20" },
    { "nom": "Solstice d’été", "date": "2030-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2030-09-22" },
    { "nom": "Solstice d’hiver", "date": "2030-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2031-03-20" },
    { "nom": "Solstice d’été", "date": "2031-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2031-09-23" },
    { "nom": "Solstice d’hiver", "date": "2031-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2032-03-20" },
    { "nom": "Solstice d’été", "date": "2032-06-20" },
    { "nom": "Équinoxe d’automne", "date": "2032-09-22" },
    { "nom": "Solstice d’hiver", "date": "2032-12-21" },
    
        { "nom": "Équinoxe de printemps", "date": "2033-03-20" },
    { "nom": "Solstice d’été", "date": "2033-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2033-09-23" },
    { "nom": "Solstice d’hiver", "date": "2033-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2034-03-20" },
    { "nom": "Solstice d’été", "date": "2034-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2034-09-22" },
    { "nom": "Solstice d’hiver", "date": "2034-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2035-03-20" },
    { "nom": "Solstice d’été", "date": "2035-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2035-09-23" },
    { "nom": "Solstice d’hiver", "date": "2035-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2036-03-20" },
    { "nom": "Solstice d’été", "date": "2036-06-20" },
    { "nom": "Équinoxe d’automne", "date": "2036-09-22" },
    { "nom": "Solstice d’hiver", "date": "2036-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2037-03-20" },
    { "nom": "Solstice d’été", "date": "2037-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2037-09-23" },
    { "nom": "Solstice d’hiver", "date": "2037-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2038-03-20" },
    { "nom": "Solstice d’été", "date": "2038-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2038-09-22" },
    { "nom": "Solstice d’hiver", "date": "2038-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2039-03-20" },
    { "nom": "Solstice d’été", "date": "2039-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2039-09-23" },
    { "nom": "Solstice d’hiver", "date": "2039-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2040-03-20" },
    { "nom": "Solstice d’été", "date": "2040-06-20" },
    { "nom": "Équinoxe d’automne", "date": "2040-09-22" },
    { "nom": "Solstice d’hiver", "date": "2040-12-21" },
    
        { "nom": "Équinoxe de printemps", "date": "2041-03-20" },
    { "nom": "Solstice d’été", "date": "2041-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2041-09-23" },
    { "nom": "Solstice d’hiver", "date": "2041-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2042-03-20" },
    { "nom": "Solstice d’été", "date": "2042-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2042-09-22" },
    { "nom": "Solstice d’hiver", "date": "2042-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2043-03-20" },
    { "nom": "Solstice d’été", "date": "2043-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2043-09-23" },
    { "nom": "Solstice d’hiver", "date": "2043-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2044-03-20" },
    { "nom": "Solstice d’été", "date": "2044-06-20" },
    { "nom": "Équinoxe d’automne", "date": "2044-09-22" },
    { "nom": "Solstice d’hiver", "date": "2044-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2045-03-20" },
    { "nom": "Solstice d’été", "date": "2045-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2045-09-23" },
    { "nom": "Solstice d’hiver", "date": "2045-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2046-03-20" },
    { "nom": "Solstice d’été", "date": "2046-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2046-09-22" },
    { "nom": "Solstice d’hiver", "date": "2046-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2047-03-20" },
    { "nom": "Solstice d’été", "date": "2047-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2047-09-23" },
    { "nom": "Solstice d’hiver", "date": "2047-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2048-03-20" },
    { "nom": "Solstice d’été", "date": "2048-06-20" },
    { "nom": "Équinoxe d’automne", "date": "2048-09-22" },
    { "nom": "Solstice d’hiver", "date": "2048-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2049-03-20" },
    { "nom": "Solstice d’été", "date": "2049-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2049-09-23" },
    { "nom": "Solstice d’hiver", "date": "2049-12-21" },

    { "nom": "Équinoxe de printemps", "date": "2050-03-20" },
    { "nom": "Solstice d’été", "date": "2050-06-21" },
    { "nom": "Équinoxe d’automne", "date": "2050-09-22" },
    { "nom": "Solstice d’hiver", "date": "2050-12-21" },
  ],
    fetesFixes: [
    { nom: "Nouvel An", mois: 1, jour: 1 },
    { nom: "Chandeleur", mois: 2, jour: 2 },
    { nom: "Fête de la musique", mois: 6, jour: 21 },
    { nom: "Halloween", mois: 10, jour: 31 },
    { nom: "Noël", mois: 12, jour: 25 }
    ]
}

