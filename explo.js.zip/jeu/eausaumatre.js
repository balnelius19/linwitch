// eausaumatre.js — version non-module
window.brackish = new Set();
const brKey = (x, y) => `${x},${y}`;

window.addBrackishTile = function(x, y) {
  brackish.add(brKey(x, y));
};

window.isBrackish = function(x, y) {
  return brackish.has(brKey(x, y));
};

window.setRandomBrackishFromWater = function(waterTiles, percent) {
  brackish.clear();
  const total = waterTiles.length;
  const targetCount = Math.floor(total * (percent / 100));
  const shuffled = waterTiles.slice().sort(() => Math.random() - 0.5);
  for (let i = 0; i < targetCount; i++) {
    const [x, y] = shuffled[i];
    addBrackishTile(x, y);
  }
};


