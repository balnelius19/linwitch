(() => {
  // Constantes
  const TILE = 24;
  const WORLD_W = 800;
  const WORLD_H = 800;
  const WALL_CHANCE = 0.46;
  const SMOOTH_STEPS = 4;

  // Canvas
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  let dpr = 1;
  function resize() {
    dpr = Math.max(1, Math.floor(window.devicePixelRatio || 1));
    canvas.width = Math.floor(window.innerWidth * dpr);
    canvas.height = Math.floor(window.innerHeight * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  window.addEventListener('resize', resize);
  resize();

  // Monde
  let world = [];
  let player = { x: Math.floor(WORLD_W / 2), y: Math.floor(WORLD_H / 2) };

  function mulberry32(a) {
    return function() {
      let t = a += 0x6D2B79F5;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    }
  }

  function makeWorld(seed = (Math.random() * 1e9) | 0) {
    const rand = mulberry32(seed);
    let g = Array.from({ length: WORLD_H }, () => Array(WORLD_W).fill(0).map(() => rand() < WALL_CHANCE ? 1 : 0));

    const dirs = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,1],[1,-1],[-1,-1]];
    const countWalls = (x, y, grid) => {
      let c = 0;
      for (const [dx, dy] of dirs) {
        const nx = (x + dx + WORLD_W) % WORLD_W;
        const ny = (y + dy + WORLD_H) % WORLD_H;
        c += grid[ny][nx] ? 1 : 0;
      }
      return c;
    };

    for (let step = 0; step < SMOOTH_STEPS; step++) {
      const ng = Array.from({ length: WORLD_H }, () => Array(WORLD_W));
      for (let y = 0; y < WORLD_H; y++) {
        for (let x = 0; x < WORLD_W; x++) {
          const walls = countWalls(x, y, g);
          ng[y][x] = walls > 4 ? 1 : (walls < 4 ? 0 : g[y][x]);
        }
      }
      g = ng;
    }

    let cx = Math.floor(WORLD_W / 2), cy = Math.floor(WORLD_H / 2);
    if (g[cy][cx] === 1) {
      let found = false;
      for (let r = 1; !found && r < Math.max(WORLD_W, WORLD_H); r++) {
        for (let y = cy - r; y <= cy + r; y++) {
          for (let x = cx - r; x <= cx + r; x++) {
            const wx = (x + WORLD_W) % WORLD_W;
            const wy = (y + WORLD_H) % WORLD_H;
            if (g[wy][wx] === 0) { cx = wx; cy = wy; found = true; break; }
          }
          if (found) break;
        }
      }
    }

    player.x = cx; player.y = cy;
    return g;
  }

  function regenerate() {
    world = makeWorld();
    if (window.survival && survival.onWorldGenerated) survival.onWorldGenerated(window.Game);
  }

  const keys = new Set();
  window.addEventListener('keydown', (e) => {
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
      e.preventDefault();
      keys.add(e.key);
    }
  });
  window.addEventListener('keyup', (e) => keys.delete(e.key));
  document.getElementById('regen').addEventListener('click', regenerate);

  let moveCooldown = 0;
  function step(dt) {
    moveCooldown -= dt;
    if (moveCooldown <= 0) {
      let dx = 0, dy = 0;
      if (keys.has('ArrowLeft')) dx = -1;
      else if (keys.has('ArrowRight')) dx = 1;
      if (keys.has('ArrowUp')) dy = -1;
      else if (keys.has('ArrowDown')) dy = 1;

      if (dx !== 0 || dy !== 0) {
        const nx = (player.x + dx + WORLD_W) % WORLD_W;
        const ny = (player.y + dy + WORLD_H) % WORLD_H;
        if (world[ny][nx] === 0) {
          player.x = nx;
          player.y = ny;

          // ✅ Mise à jour du score
          if (window.GameScore) {
            GameScore.increment(); // +1 à chaque déplacement valide
          }
        }
        moveCooldown = 120;
      }
    }
    if (window.survival && survival.onUpdate) survival.onUpdate(window.Game, dt);
  }

  function draw() {
    ctx.fillStyle = '#111';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const tilesW = Math.ceil(window.innerWidth / TILE) + 2;
    const tilesH = Math.ceil(window.innerHeight / TILE) + 2;
    const halfW = Math.floor(tilesW / 2);
    const halfH = Math.floor(tilesH / 2);
    const worldX0 = player.x - halfW;
    const worldY0 = player.y - halfH;

    for (let sy = 0; sy < tilesH; sy++) {
      const wy = (worldY0 + sy + WORLD_H) % WORLD_H;
      const py = sy * TILE;
      for (let sx = 0; sx < tilesW; sx++) {
        const wx = (worldX0 + sx + WORLD_W) % WORLD_W;
        const px = sx * TILE;

        if (world[wy][wx]) {
          ctx.fillStyle = '#2a2a2e';
          ctx.fillRect(px, py, TILE, TILE);
        } else {
          ctx.fillStyle = '#3a3a42';
          ctx.fillRect(px, py, TILE, TILE);
          ctx.fillStyle = 'rgba(255,255,255,0.03)';
          ctx.fillRect(px + 8, py + 8, 2, 2);
        }

        if (window.survival && survival.drawTileOverlay) {
          survival.drawTileOverlay(ctx, wx, wy, px, py, TILE);
        }
      }
    }

    const ppx = halfW * TILE;
    const ppy = halfH * TILE;
    ctx.fillStyle = '#4fd1c5';
    ctx.fillRect(ppx + 2, ppy + 2, TILE - 4, TILE - 4);

    const grd = ctx.createRadialGradient(
      ppx + TILE / 2, ppy + TILE / 2, TILE * 2,
      ppx + TILE / 2, ppy + TILE / 2, Math.max(window.innerWidth, window.innerHeight) / 1.2
    );
    grd.addColorStop(0, 'rgba(0,0,0,0)');
    grd.addColorStop(1, 'rgba(0,0,0,0.35)');
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (window.survival && survival.drawHUD) survival.drawHUD(ctx, canvas);
  }

  let last = performance.now();
  function loop(t) {
    const dt = t - last; last = t;
    step(dt);
    draw();
    requestAnimationFrame(loop);
  }

  window.Game = {
    get world() { return world; },
    get player() { return player; },
    get TILE() { return TILE; },
    get WORLD_W() { return WORLD_W; },
    get WORLD_H() { return WORLD_H; }
  };

  regenerate();
  requestAnimationFrame(loop);
})();
