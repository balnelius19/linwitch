// score.js
window.GameScore = {
  value: 0,
  history: [],

  increment(amount = 1) {
    this.value += amount;
    this.updateDisplay();
  },

  reset() {
    this.history.push(this.value);
    this.value = 0;
    this.updateDisplay();
  },

  updateDisplay() {
    const el = document.getElementById('score');
    if (el) el.textContent = `Score : ${this.value}`;
  }
};

window.addEventListener('DOMContentLoaded', () => {
  GameScore.updateDisplay();
});
