(() => {
  const survival = {};
  window.survival = survival;

  const HUNGER_MAX = 100, THIRST_MAX = 100;
  const HUNGER_DECAY_PER_S = 0.4, THIRST_DECAY_PER_S = 0.7;
  const DRINK_AMOUNT = 35, EAT_AMOUNT = 22, EAT_THIRST_BONUS = 3;
  const INPUT_COOLDOWN_MS = 200;
  const WATER_PATCHES = 60, WATER_RADIUS_MIN = 3, WATER_RADIUS_MAX = 7;
  const BERRY_BUSHES = 280, BERRY_PER_BUSH = 2, BERRY_REGROW_MS = 30000;

  let hunger = HUNGER_MAX, thirst = THIRST_MAX;
  const water = new Set();
  const berries = new Map();
  const keyOf = (x, y) => `${x},${y}`;
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

  function isFreeTile(G, x, y) {
    const k = keyOf(x, y);
    return G.world[y] && G.world[y][x] === 0 && !water.has(k) && !berries.has(k);
  }

  function placeRandomWaterTile(G, maxTries = 1000) {
    let tries = 0;
    while (tries++ < maxTries) {
      const x = Math.floor(Math.random() * G.WORLD_W);
      const y = Math.floor(Math.random() * G.WORLD_H);
      if (isFreeTile(G, x, y)) {
        water.add(keyOf(x, y));
        return true;
      }
    }
    return false;
  }

  function placeRandomBerryBush(G, maxTries = 1000) {
    let tries = 0;
    while (tries++ < maxTries) {
      const x = Math.floor(Math.random() * G.WORLD_W);
      const y = Math.floor(Math.random() * G.WORLD_H);
      if (isFreeTile(G, x, y)) {
        berries.set(keyOf(x, y), { count: BERRY_PER_BUSH, nextGrowAt: 0 });
        return true;
      }
    }
    return false;
  }

  // Actions E/F
  let lastActionAt = 0;
  window.addEventListener('keydown', (e) => {
    if (e.code === 'KeyE' || e.code === 'KeyF') {
      e.preventDefault();
      const now = performance.now();
      if (now - lastActionAt < INPUT_COOLDOWN_MS) return;
      lastActionAt = now;

      const G = window.Game;
      if (!G) return;
      const { player, WORLD_W, WORLD_H } = G;
      const px = ((player.x % WORLD_W) + WORLD_W) % WORLD_W;
      const py = ((player.y % WORLD_H) + WORLD_H) % WORLD_H;
      const k = keyOf(px, py);

      if (e.code === 'KeyE' && water.has(k)) {
        thirst = clamp(thirst + DRINK_AMOUNT, 0, THIRST_MAX);
        water.delete(k);
        placeRandomWaterTile(G);
      } else if (e.code === 'KeyF') {
        const b = berries.get(k);
        if (b && b.count > 0) {
          b.count--;
          hunger = clamp(hunger + EAT_AMOUNT, 0, HUNGER_MAX);
          thirst = clamp(thirst + EAT_THIRST_BONUS, 0, THIRST_MAX);
          if (b.count === 0) {
            berries.delete(k);
            placeRandomBerryBush(G);
          } else if (b.count < BERRY_PER_BUSH && b.nextGrowAt === 0) {
            b.nextGrowAt = now + BERRY_REGROW_MS;
          }
        }
      }
    }
  });

  // Hooks
  survival.onWorldGenerated = (G) => {
    water.clear(); berries.clear();
    const { world, WORLD_W, WORLD_H } = G;

    // Eau douce
    for (let i = 0; i < WATER_PATCHES; i++) {
      const cx = Math.floor(Math.random() * WORLD_W);
      const cy = Math.floor(Math.random() * WORLD_H);
      const r = Math.floor(Math.random() * (WATER_RADIUS_MAX - WATER_RADIUS_MIN + 1)) + WATER_RADIUS_MIN;
      for (let dy = -r; dy <= r; dy++) {
        for (let dx = -r; dx <= r; dx++) {
          if (dx*dx + dy*dy <= r*r) {
            const x = (cx + dx + WORLD_W) % WORLD_W;
            const y = (cy + dy + WORLD_H) % WORLD_H;
            if (world[y] && world[y][x] === 0) {
              water.add(keyOf(x, y));
            }
          }
        }
      }
    }

    // Baies
    let placed = 0, guard = 0;
    while (placed < BERRY_BUSHES && guard++ < BERRY_BUSHES * 20) {
      const x = Math.floor(Math.random() * WORLD_W);
      const y = Math.floor(Math.random() * WORLD_H);
      if (world[y] && world[y][x] === 0 && !water.has(keyOf(x, y))) {
        berries.set(keyOf(x, y), { count: BERRY_PER_BUSH, nextGrowAt: 0 });
        placed++;
      }
    }

    hunger = clamp(hunger, 0, HUNGER_MAX);
    thirst = clamp(thirst, 0, THIRST_MAX);

    // Ajout eau saumâtre ici
    const allWaterTiles = Array.from(water).map(k => k.split(',').map(Number));
    if (typeof setRandomBrackishFromWater === 'function') {
      setRandomBrackishFromWater(allWaterTiles, 30);
    }
  };

  survival.onUpdate = (G, dtMs) => {
    const dt = dtMs / 1000;
    hunger = clamp(hunger - HUNGER_DECAY_PER_S * dt, 0, HUNGER_MAX);
    thirst = clamp(thirst - THIRST_DECAY_PER_S * dt, 0, THIRST_MAX);
    const now = performance.now();
    for (const [k, b] of berries) {
      if (b.count < BERRY_PER_BUSH && b.nextGrowAt !== 0 && now >= b.nextGrowAt) {
        b.count++;
        b.nextGrowAt = (b.count < BERRY_PER_BUSH) ? now + BERRY_REGROW_MS : 0;
      }
    }
  };

  survival.drawTileOverlay = (ctx, wx, wy, px, py, TILE) => {
    const k = keyOf(wx, wy);
    if (water.has(k)) {
      if (typeof isBrackish === 'function' && isBrackish(wx, wy)) {
        const grad = ctx.createLinearGradient(px, py, px + TILE, py);
        grad.addColorStop(0, '#2e78ff');
        grad.addColorStop(1, '#a37c40');
        ctx.fillStyle = grad;
      } else {
        ctx.fillStyle = '#2e78ff';
      }
      ctx.fillRect(px, py, TILE, TILE);
    }
    const b = berries.get(k);
    if (b && b.count > 0) {
      const cx = px + TILE / 2, cy = py + TILE / 2;
      const r = Math.max(3, Math.floor(TILE * 0.18));
      ctx.fillStyle = '#c84bd6';
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(200,75,214,0.15)';
      ctx.beginPath(); ctx.arc(cx, cy, r * 1.8, 0, Math.PI * 2); ctx.fill();
    }
  };

  survival.drawHUD = (ctx, canvas) => {
    const PAD = 12, BAR_W = 200, BAR_H = 10, GAP = 8;
    const x = PAD, y0 = PAD;
    ctx.save();
    ctx.font = '14px system-ui, sans-serif';
    ctx.textBaseline = 'top';
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.fillRect(x - 8, y0 - 8, BAR_W + 16, BAR_H * 2 + GAP + 16 + 18);
    drawBar(ctx, x, y0, BAR_W, BAR_H, hunger / HUNGER_MAX, '#f6ad55', '#78350f');
    ctx.fillStyle = '#ddd'; ctx.fillText('Faim', x + BAR_W + 10, y0 - 2);
    drawBar(ctx, x, y0 + BAR_H + GAP, BAR_W, BAR_H, thirst / THIRST_MAX, '#63b3ed', '#1a365d');
    ctx.fillStyle = '#ddd'; ctx.fill

    ctx.fillText('Soif', x + BAR_W + 10, y0 + BAR_H + GAP - 2);

    ctx.fillStyle = '#bbb';
    ctx.fillText('E: boire (sur eau)   F: manger (sur baies)', x, y0 + BAR_H * 2 + GAP + 10);

    ctx.restore();
  };

  function drawBar(ctx, x, y, w, h, p, fg, bg) {
    p = clamp(p, 0, 1);
    ctx.fillStyle = bg;
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = fg;
    ctx.fillRect(x, y, Math.floor(w * p), h);
    ctx.strokeStyle = 'rgba(255,255,255,0.2)';
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
  }

  // Si le jeu est déjà prêt quand ce module est chargé
  if (window.Game && survival.onWorldGenerated) {
    survival.onWorldGenerated(window.Game);
  }
})();

// --- Expose certaines données pour modules externes (ex: eausaumatre.js) ---
Object.defineProperty(survival, 'hunger', {
  get: () => hunger,
  set: v => { hunger = v; }
});
Object.defineProperty(survival, 'thirst', {
  get: () => thirst,
  set: v => { thirst = v; }
});
GameScore.increment(); // ajoute 1 point
GameScore.reset();     // remet à zéro et sauvegarde dans l’historique


